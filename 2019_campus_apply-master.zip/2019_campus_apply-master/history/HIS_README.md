### 七、开发利器

- IntelliJ IDEA 
  - 学习课程：IntelliJ IDEA神器使用技巧 |[慕课网](https://www.imooc.com/learn/924)
  - 使用笔记：[Idea工具常用技巧总结](https://www.jianshu.com/p/131c2deb3ecf)





## PART2：学习记录

详情转向 [course/LEARN.md](course/LEARN.md)





## 附录：后端研发工程师_Skills Tree

**![](D:/gitdoc/2019_campus_appy/pics/mind/developer_skills_tree.svg)**