
# 文档格式

## 1. 图片格式



<div align="center"> <img src="../pics/hash-to-badlink.png" width=""/></div><br/>

<div align="center"> <img src="pics/concurrent_and_parallel.png" width=""/></div><br/>

<div align="center"><img src="" width=""/></div><br/>

<div align="center"><img src="" width=""/></div>


## 2. 段首空格
　　这里开始是我的正文内容







Eemoji from ：[EMOJI CHEAT SHEET](https://www.webpagefx.com/tools/emoji-cheat-sheet/) , [Emojipedia](https://emojipedia.org/)  | [Shields.io](https://shields.io/#/)



```shell
pandoc -s --toc FAQ.md -o FAQ.md
```

[实用帖 | 如何为 Markdown 文件自动生成目录？ - 简书](https://www.jianshu.com/p/4721ddd27027)
