高并发网络编程之epoll详解 - CSDN博客
https://blog.csdn.net/shenya1314/article/details/73691088





## RMI

在RMI中通过代理模式实现



## RPC

