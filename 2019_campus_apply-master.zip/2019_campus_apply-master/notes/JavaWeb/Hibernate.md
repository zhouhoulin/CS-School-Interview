> hibernate 美 /'haɪbɚnet/ vi. 过冬；（动物）冬眠；（人等）避寒





