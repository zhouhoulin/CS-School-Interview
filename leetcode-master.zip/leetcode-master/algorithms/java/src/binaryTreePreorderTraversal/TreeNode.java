package binaryTreePreorderTraversal;

/**
 * Created by leicao on 5/10/15.
 */
public class TreeNode {
     int val;
     TreeNode left;
     TreeNode right;
     TreeNode(int x) { val = x; }
}
