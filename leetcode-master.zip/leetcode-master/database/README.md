### LeetCode Database


| # | Title | Solution | Difficulty |
|---| ----- | -------- | ---------- |
|1|[Trips and Users](https://leetcode.com/problems/trips-and-users/)| [MySQL](./TripsAndUsers.sql)|Hard|
