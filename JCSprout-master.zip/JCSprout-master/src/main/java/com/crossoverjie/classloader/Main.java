package com.crossoverjie.classloader;

/**
 * Function:
 *
 * @author crossoverJie
 *         Date: 05/03/2018 23:12
 * @since JDK 1.8
 */
public class Main {
    public static void main(String[] args) {
        System.out.println(ChildClass.A);
    }
}
