<!-- GFM-TOC -->
* [0. 进程内存空间中，堆和栈的区别](#0-进程内存空间中，堆和栈的区别)
<!-- GFM-TOC -->


# 0. 进程内存空间中，堆和栈的区别

> C++

堆：动态、malloc()、new、链式分配、向上生长；栈：函数调用、编译器分配回收、向下生长。

https://www.cnblogs.com/sunziying/p/6510030.html

By @CyC

---
